# 📋 TÓPICOS DESCOBERTOS NO GRUPO

🏠 Grupo: -1002966479273
📊 Total: 11 tópicos

1. 🆘 Suporte Gamer
   🆔 ID: 148
   📅 Descoberto: 2025-09-24 20:22:58
   🕒 Última atividade: 2025-09-24 17:22:58

2. teste
   🆔 ID: 3
   📅 Descoberto: 2025-09-24 20:21:29
   🕒 Última atividade: 2025-09-24 17:21:29

3. 🧙 RPG & MMORPG
   🆔 ID: 27
   📅 Descoberto: 2025-09-24 20:17:40
   🕒 Última atividade: 2025-09-24 17:17:40

4. ⚽️ Esportes & Corrida
   🆔 ID: 29
   📅 Descoberto: 2025-09-24 20:17:40
   🕒 Última atividade: 2025-09-24 17:17:40

5. 🕹 Retro & Indie
   🆔 ID: 31
   📅 Descoberto: 2025-09-24 20:17:39
   🕒 Última atividade: 2025-09-24 17:17:39

6. 🎧 Setup & Periféricos
   🆔 ID: 33
   📅 Descoberto: 2025-09-24 20:17:38
   🕒 Última atividade: 2025-09-24 17:17:38

7. 🎮 Jogos FPS & Battle Royale
   🆔 ID: 25
   📅 Descoberto: 2025-09-24 20:17:37
   🕒 Última atividade: 2025-09-24 17:17:37

8. 🎉 Eventos & Promoções OnCabo
   🆔 ID: 106
   📅 Descoberto: 2025-09-24 20:17:35
   🕒 Última atividade: 2025-09-24 17:17:35

9. ##Avisos & Updates##
   🆔 ID: 14
   📅 Descoberto: 2025-09-24 20:17:32
   🕒 Última atividade: 2025-09-24 17:17:32

10. 📋 Regras da Comunidade
   🆔 ID: 87
   📅 Descoberto: 2025-09-24 20:17:30
   🕒 Última atividade: 2025-09-24 17:17:30

11. 👋 Boas-vindas Gamer OnCabo
   🆔 ID: 89
   📅 Descoberto: 2025-09-24 20:17:30
   🕒 Última atividade: 2025-09-24 17:17:29

---
*Arquivo salvo automaticamente - não será enviado ao GitHub*
*Localizado em: data/topicos_descobertos.md*